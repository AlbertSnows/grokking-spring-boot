package com.example.relationaldataaccess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationalDataAccessApplicationTests {

	@Test
	void contextLoads() {
	}

}
